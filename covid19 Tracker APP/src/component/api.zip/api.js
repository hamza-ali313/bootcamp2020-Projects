import axios from "axios";
 
const url ="https://covid19.mathdro.id/api";


export const fetchedData = async ()=>{
try{
const {data:{confirmed,recovered,deaths,lastUpdate}} = await axios.get(url);
 
return{confirmed,recovered,deaths,lastUpdate}

 } catch(error){

 }
};
export const fetchDailyData = async ()=>{
    try{
    const {dailyData} = await axios.get(`${url}/daily`);
     
    return dailyData
    
     } catch(error){
    
     }
    };
    